var data = require('./label_studio.json');
//console.log(data[0].annotations[0].result);

var result = {"02.mp4":[], "01.mp4":[]};
cnt=0;
for(var v in result){
    for(var a of data[cnt].annotations[0].result){
        //console.log(a);
        for(var i in a.value.sequence){
            if(i&1){
                result[v][result[v].length-1].end_frame=a.value.sequence[i].frame.toString();
            }else{
                result[v][result[v].length]={
                    "start_frame": a.value.sequence[i].frame.toString(),
                    "action_type": a.value.labels[0],
                    "down_coordinate": [a.value.sequence[i].x+a.value.sequence[i].width/2, a.value.sequence[i].y+a.value.sequence[i].height/2],
                    "up_coordinate": [a.value.sequence[i].x+a.value.sequence[i].width/2, a.value.sequence[i].y+a.value.sequence[i].height/2],
                    "type_word": null
                }
                if(a.value.labels[0]=="swipe"){
                    result[v][result[v].length-1].down_coordinate=[a.value.sequence[i].x+a.value.sequence[i].width/2, a.value.sequence[i].y];
                    result[v][result[v].length-1].up_coordinate=[a.value.sequence[i].x+a.value.sequence[i].width/2, a.value.sequence[i].y+a.value.sequence[i].height];
                }else if(a.value.labels[0]=="type"){
                    result[v][result[v].length-1].type_word="abcdefg";
                }
            }
        }
    }
    cnt++;
}

var fs = require("fs");
fs.writeFileSync('annotate.json', JSON.stringify(result));